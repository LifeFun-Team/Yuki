const owner = '<:owner:722841140591853621>';
const music = '<a:music:648272969755394071>';
module.exports = { owner, music }
