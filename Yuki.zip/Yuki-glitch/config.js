module.exports = {
  prefix: "u!",
  color: "#9999ff",
  invisible: "#2f3136",
  sdc: "https://bots.server-discord.com/618162110710677524",
  owners: ["543067684494114817", "441954631539490857"],
  sponsors: ["543067684494114817", "441954631539490857"]
};
